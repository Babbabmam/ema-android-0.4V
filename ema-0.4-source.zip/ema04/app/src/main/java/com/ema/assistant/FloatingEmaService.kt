package com.ema.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.widget.Toast
import kotlin.math.abs

class FloatingEmaService : Service() {
    private lateinit var windowManager: WindowManager
    private var characterView: ImageView? = null
    private var params: WindowManager.LayoutParams? = null
    private var menu: PopupWindow? = null
    private var bubble: PopupWindow? = null
    private val channelId = "ema_floating_character"

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(77, buildNotification())
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        addCharacter()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Плавающий емА", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("емА работает")
            .setContentText("Персонаж отображается поверх приложений")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }

    private fun addCharacter() {
        val image = ImageView(this).apply {
            setImageResource(R.drawable.ema_character)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Плавающий персонаж емА"
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val layout = WindowManager.LayoutParams(
            dp(112), dp(112), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(20)
            y = dp(180)
        }
        params = layout
        characterView = image
        windowManager.addView(image, layout)

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var dragged = false
        image.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = layout.x
                    startY = layout.y
                    touchX = event.rawX
                    touchY = event.rawY
                    dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > dp(5) || abs(dy) > dp(5)) dragged = true
                    layout.x = startX + dx
                    layout.y = startY + dy
                    try { windowManager.updateViewLayout(image, layout) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) showMenu(image, layout)
                    true
                }
                else -> false
            }
        }
        showBubble(image, layout)
    }

    private fun showBubble(anchor: View, layout: WindowManager.LayoutParams, message: String = "Привет! Я емА.") {
        try { bubble?.dismiss() } catch (_: Exception) {}
        val text = TextView(this).apply {
            text = message
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(Color.rgb(45, 54, 78))
        }
        bubble = PopupWindow(text, dp(150), dp(48), false).also {
            it.isTouchable = false
            it.isOutsideTouchable = false
            try { it.showAtLocation(anchor, Gravity.TOP or Gravity.START, layout.x, (layout.y - dp(50)).coerceAtLeast(dp(8))) } catch (_: Exception) {}
            text.postDelayed({ try { it.dismiss() } catch (_: Exception) {} }, 6000)
        }
    }

    private fun showMenu(anchor: View, layout: WindowManager.LayoutParams) {
        menu?.dismiss()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = rounded(Color.rgb(28, 31, 43))
        }
        val title = TextView(this).apply {
            text = "емА"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(6))
        }
        panel.addView(title)
        addMenuButton(panel, "Открыть приложение") {
            val launch = packageManager.getLaunchIntentForPackage(packageName)
            launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (launch != null) startActivity(launch)
            menu?.dismiss()
        }
        addMenuButton(panel, "Приветствие") {
            showBubble(anchor, layout, "Я здесь! Чем займёмся?")
            menu?.dismiss()
        }
        addMenuButton(panel, "Убрать персонажа") {
            menu?.dismiss()
            stopSelf()
        }
        menu = PopupWindow(panel, dp(210), WindowManager.LayoutParams.WRAP_CONTENT, true).apply {
            isOutsideTouchable = true
            elevation = dp(8).toFloat()
            try { showAtLocation(anchor, Gravity.TOP or Gravity.START, layout.x, (layout.y + dp(110)).coerceAtMost(resources.displayMetrics.heightPixels - dp(190))) } catch (_: Exception) {}
        }
    }

    private fun addMenuButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 13f
            setOnClickListener { action() }
        }
        parent.addView(button)
    }

    private fun rounded(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(14).toFloat()
        setStroke(dp(1), Color.rgb(90, 110, 145))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try { menu?.dismiss() } catch (_: Exception) {}
        try { bubble?.dismiss() } catch (_: Exception) {}
        try { characterView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        characterView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
