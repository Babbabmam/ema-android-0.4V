package com.ema.assistant

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.graphics.Color
import android.media.MediaPlayer
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.VideoView
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private var player: MediaPlayer? = null
    private var selectedAudio: Uri? = null
    private var selectedStreamUrl: String? = null
    private var repeatEnabled = true
    private lateinit var streamInput: EditText
    private lateinit var repeatButton: Button
    private lateinit var status: TextView
    private lateinit var playButton: Button
    private lateinit var cityInput: EditText
    private lateinit var weatherText: TextView

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        val backgroundVideo = VideoView(this).apply {
            setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.ema_background}"))
            setOnPreparedListener { mediaPlayer ->
                mediaPlayer.isLooping = true
                mediaPlayer.setVolume(0f, 0f)
                start()
            }
        }
        root.addView(backgroundVideo, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
            setBackgroundColor(Color.argb(155, 18, 20, 29))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        scroll.addView(content)
        page.addView(scroll)
        root.addView(page, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))
        setContentView(root)

        val title = TextView(this).apply {
            text = "емА"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        content.addView(title)

        val character = ImageView(this).apply {
            setImageResource(R.drawable.ema_character)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }
        content.addView(character, LinearLayout.LayoutParams(dp(230), dp(230)))

        val subtitle = TextView(this).apply {
            text = "Плавающий персонаж емА"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        content.addView(subtitle)
        addSpace(content, 12)

        val overlayButton = makeButton("Включить плавающего емА")
        content.addView(overlayButton, matchWidth())
        overlayButton.setOnClickListener { enableFloatingCharacter() }

        val hint = TextView(this).apply {
            text = "После выдачи разрешения персонаж появится поверх других приложений. Перетаскивай его пальцем, нажимай для меню. Чтобы убрать — нажми «Отключить» в меню персонажа."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        content.addView(hint)
        addSpace(content, 20)

        section(content, "Погода")
        cityInput = EditText(this).apply {
            hint = "Город, например Berlin"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.rgb(42, 46, 60))
        }
        content.addView(cityInput, matchWidth())
        val weatherButton = makeButton("Показать погоду")
        content.addView(weatherButton, matchWidth())
        weatherText = TextView(this).apply {
            text = "Введи город и нажми кнопку."
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        content.addView(weatherText)
        weatherButton.setOnClickListener { loadWeather(cityInput.text.toString().trim()) }

        addSpace(content, 20)
        section(content, "Музыкальный плеер")
        status = TextView(this).apply {
            text = "Пока файл не выбран."
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            textSize = 14f
        }
        content.addView(status)
        val chooseButton = makeButton("Выбрать аудиофайл")
        content.addView(chooseButton, matchWidth())
        playButton = makeButton("Воспроизвести")
        content.addView(playButton, matchWidth())
        val stopButton = makeButton("Остановить")
        content.addView(stopButton, matchWidth())
        streamInput = EditText(this).apply {
            hint = "Прямая ссылка на MP3 / аудиофайл"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.rgb(42, 46, 60))
        }
        content.addView(streamInput, matchWidth())
        val streamButton = makeButton("Играть по ссылке")
        content.addView(streamButton, matchWidth())
        val saveButton = makeButton("Сохранить аудио по ссылке")
        content.addView(saveButton, matchWidth())
        repeatButton = makeButton("Повтор: включён")
        content.addView(repeatButton, matchWidth())
        repeatButton.setOnClickListener {
            repeatEnabled = !repeatEnabled
            repeatButton.text = if (repeatEnabled) "Повтор: включён" else "Повтор: выключен"
            player?.isLooping = repeatEnabled
        }
        streamButton.setOnClickListener { playStream(streamInput.text.toString().trim()) }
        saveButton.setOnClickListener { saveStream(streamInput.text.toString().trim()) }

        chooseButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "audio/*"
            }
            startActivityForResult(intent, PICK_AUDIO)
        }
        playButton.setOnClickListener { togglePlayback() }
        stopButton.setOnClickListener {
            player?.let {
                if (it.isPlaying) it.stop()
                it.release()
            }
            player = null
            playButton.text = "Воспроизвести"
            status.text = if (selectedAudio == null && selectedStreamUrl == null) "Пока файл не выбран." else "Воспроизведение остановлено."
        }

        addSpace(content, 20)
        section(content, "Поиск Google")
        val searchInput = EditText(this).apply {
            hint = "Что будем искать?"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.rgb(42, 46, 60))
        }
        content.addView(searchInput, matchWidth())
        val searchButton = makeButton("Искать в Google")
        content.addView(searchButton, matchWidth())
        searchButton.setOnClickListener {
            val query = searchInput.text.toString().trim()
            if (query.isNotEmpty()) {
                val encoded = URLEncoder.encode(query, "UTF-8")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded")))
            } else {
                Toast.makeText(this, "Сначала введи запрос", Toast.LENGTH_SHORT).show()
            }
        }
        addSpace(content, 18)
        val footer = TextView(this).apply {
            text = "емА 0.3 • плавающий персонаж"
            setTextColor(Color.GRAY)
            textSize = 12f
            gravity = Gravity.CENTER
        }
        content.addView(footer)
    }

    private fun enableFloatingCharacter() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "Разреши емА показываться поверх других приложений, затем вернись и нажми кнопку ещё раз.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, FloatingEmaService::class.java)
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            Toast.makeText(this, "Плавающий емА включён", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось запустить персонажа: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun section(parent: LinearLayout, label: String) {
        val t = TextView(this).apply {
            text = label
            textSize = 21f
            setTextColor(Color.rgb(130, 190, 255))
            gravity = Gravity.CENTER
        }
        parent.addView(t)
        addSpace(parent, 8)
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(8) }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        textSize = 15f
        isAllCaps = false
    }

    private fun loadWeather(city: String) {
        if (city.isBlank()) {
            weatherText.text = "Введи название города."
            return
        }
        weatherText.text = "Загружаю погоду для $city…"
        thread {
            try {
                val encoded = URLEncoder.encode(city, "UTF-8")
                val geo = getJson("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=ru&format=json")
                val results = geo.optJSONArray("results")
                if (results == null || results.length() == 0) throw Exception("Город не найден")
                val place = results.getJSONObject(0)
                val lat = place.getDouble("latitude")
                val lon = place.getDouble("longitude")
                val name = place.optString("name", city)
                val country = place.optString("country", "")
                val forecast = getJson("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m")
                val current = forecast.getJSONObject("current")
                val temp = current.optDouble("temperature_2m")
                val feels = current.optDouble("apparent_temperature")
                val humidity = current.optInt("relative_humidity_2m")
                val wind = current.optDouble("wind_speed_10m")
                val description = weatherDescription(current.optInt("weather_code"))
                val result = "$name${if (country.isNotBlank()) ", $country" else ""}\n$description\nТемпература: ${temp.toInt()} °C\nОщущается как: ${feels.toInt()} °C\nВлажность: $humidity%\nВетер: ${wind.toInt()} км/ч"
                runOnUiThread { weatherText.text = result }
            } catch (e: Exception) {
                runOnUiThread { weatherText.text = "Не удалось получить погоду: ${e.message ?: "ошибка сети"}" }
            }
        }
    }

    private fun getJson(address: String): JSONObject {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 10000
        connection.readTimeout = 10000
        connection.requestMethod = "GET"
        return try { JSONObject(connection.inputStream.bufferedReader().use { it.readText() }) }
        finally { connection.disconnect() }
    }

    private fun weatherDescription(code: Int): String = when (code) {
        0 -> "Ясно"; 1, 2 -> "Преимущественно ясно"; 3 -> "Облачно"
        45, 48 -> "Туман"; 51, 53, 55, 56, 57 -> "Морось"
        61, 63, 65, 66, 67 -> "Дождь"; 71, 73, 75, 77 -> "Снег"
        80, 81, 82 -> "Ливень"; 85, 86 -> "Снегопад"
        95, 96, 99 -> "Гроза"; else -> "Погодные условия"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_AUDIO && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            selectedAudio = uri
            selectedStreamUrl = null
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            player?.release()
            player = null
            selectedStreamUrl = null
            status.text = "Файл выбран: ${uri.lastPathSegment ?: "аудио"}"
            playButton.text = "Воспроизвести"
        }
    }

    private fun togglePlayback() {
        val existing = player
        if (existing != null) {
            try {
                if (existing.isPlaying) { existing.pause(); playButton.text = "Продолжить" }
                else { existing.start(); playButton.text = "Пауза" }
            } catch (_: Exception) { status.text = "Не удалось управлять воспроизведением." }
            return
        }
        val uri = selectedAudio
        if (uri == null && selectedStreamUrl != null) {
            playStream(selectedStreamUrl!!)
            return
        }
        if (uri == null) {
            Toast.makeText(this, "Сначала выбери аудиофайл", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val newPlayer = MediaPlayer()
            newPlayer.setDataSource(this, uri)
            newPlayer.isLooping = repeatEnabled
            newPlayer.setOnPreparedListener {
                it.start()
                playButton.text = "Пауза"
                status.text = "Музыка воспроизводится."
            }
            newPlayer.setOnCompletionListener {
                playButton.text = "Воспроизвести"
                status.text = "Трек завершён."
                it.release()
                player = null
            }
            newPlayer.setOnErrorListener { mp, _, _ ->
                mp.release(); player = null; playButton.text = "Воспроизвести"
                status.text = "Не удалось воспроизвести этот файл."
                true
            }
            player = newPlayer
            status.text = "Подготавливаю аудио…"
            newPlayer.prepareAsync()
        } catch (e: Exception) {
            status.text = "Ошибка аудио: ${e.message}"
            player?.release(); player = null
        }
    }

    private fun playStream(address: String) {
        if (!(address.startsWith("https://") || address.startsWith("http://"))) {
            Toast.makeText(this, "Вставь прямую http(s)-ссылку на аудиофайл", Toast.LENGTH_LONG).show()
            return
        }
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(address)
                isLooping = repeatEnabled
                setOnPreparedListener {
                    it.start()
                    status.text = "Воспроизведение по ссылке."
                    playButton.text = "Пауза"
                }
                setOnCompletionListener {
                    status.text = "Трек завершён."
                    playButton.text = "Воспроизвести"
                    it.release()
                    player = null
                }
                setOnErrorListener { mp, _, _ ->
                    mp.release(); player = null
                    status.text = "Не удалось открыть ссылку. Нужна прямая ссылка на аудио."
                    true
                }
                prepareAsync()
            }
            selectedAudio = null
            selectedStreamUrl = address
            status.text = "Подключаюсь к аудио…"
        } catch (e: Exception) {
            status.text = "Ошибка ссылки: ${e.message}"
            player?.release(); player = null
        }
    }

    private fun saveStream(address: String) {
        if (!(address.startsWith("https://") || address.startsWith("http://"))) {
            Toast.makeText(this, "Вставь прямую ссылку на аудиофайл", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val fileName = Uri.parse(address).lastPathSegment?.takeIf { it.contains('.') } ?: "ema-audio.mp3"
            val request = DownloadManager.Request(Uri.parse(address))
                .setTitle(fileName)
                .setDescription("Загрузка музыки для емА")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(this, android.os.Environment.DIRECTORY_MUSIC, fileName)
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(this, "Загрузка началась. Файл сохранится в папке приложения.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось начать загрузку: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object { private const val PICK_AUDIO = 42 }
}
